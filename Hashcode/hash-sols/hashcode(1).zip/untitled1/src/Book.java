public class Book {
    int id;
    int value;

    public Book(int id, int value) {
        this.id = id;
        this.value = value;
    }
}
