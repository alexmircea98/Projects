import java.util.Comparator;

public class LibraryValueComparator implements Comparator<Library> {
    public int compare(Library a, Library b) {
        return b.value - a.value;
    }
}