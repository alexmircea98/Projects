import java.util.ArrayList;

public class Library {
    int numberOfBooks;
    int signup;
    int shipping;
    ArrayList<Book> bookList;
    int value;
    int index;
    int shippedBooks;
    ArrayList<Integer> bookShipped;


    public Library(int numberOfBooks, int signup, int shipping, int index) {
        this.numberOfBooks = numberOfBooks;
        this.signup = signup;
        this.shipping = shipping;
        this.index = index;
        bookList = new ArrayList<>();
        bookShipped = new ArrayList<>();
    }
}
