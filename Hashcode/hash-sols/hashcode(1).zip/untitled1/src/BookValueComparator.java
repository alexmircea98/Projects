import java.util.Comparator;

public class BookValueComparator implements Comparator<Book> {
    public int compare(Book a, Book b) {
        return b.value - a.value;
    }
}
